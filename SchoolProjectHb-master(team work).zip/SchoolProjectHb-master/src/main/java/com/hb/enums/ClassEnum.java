package com.hb.enums;

public enum ClassEnum {

	A,
	B,
	C,
	D,
	E
}
