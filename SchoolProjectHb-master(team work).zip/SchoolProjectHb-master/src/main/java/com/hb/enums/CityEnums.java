package com.hb.enums;

public enum CityEnums {
	
	ISTANBUL,
	ANKARA,
	IZMIR,
	ADANA,
	MERSIN,
	SAMSUN,
	CANAKKALE,
	MANISA


}
