package com.hb.enums;

public enum CourseEnums {
	
	BIOLOGY,
	MATHEMATICS,
	PHYSICS,
	CHEMISTRY,
	LITERATURE

}
