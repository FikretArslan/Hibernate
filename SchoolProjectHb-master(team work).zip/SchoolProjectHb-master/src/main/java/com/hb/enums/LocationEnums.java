package com.hb.enums;

public enum LocationEnums {
	HOME,
	SCHOOL,
	PREPSCHOOL
}
