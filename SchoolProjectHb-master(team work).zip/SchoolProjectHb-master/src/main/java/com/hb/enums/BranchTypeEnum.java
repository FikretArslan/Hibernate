package com.hb.enums;

public enum BranchTypeEnum {
	
	MATEMATIK,
	FIZIK,
	KIMYA,
	BIYOLOJI

}
